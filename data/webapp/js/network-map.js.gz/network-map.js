/**
 * Network Map Visualization
 * 
 * Interactive canvas-based visualization of discovered LoRa devices.
 * Positions nodes based on RSSI (signal strength = estimated distance).
 */

// Debug configuration - shared pattern with app.js
const MAP_DEBUG = {
    enabled: false,  // Set to true for verbose canvas logging
    log: (...args) => MAP_DEBUG.enabled && console.log('[NetworkMap]', ...args),
    warn: (...args) => console.warn('[NetworkMap]', ...args),
    error: (...args) => console.error('[NetworkMap]', ...args)
};

// escapeHtml is defined in toast.js (loaded first) and exported as window.escapeHtml

/**
 * Configuration constants for network map visualization
 * Centralized magic numbers for easy tuning
 * @namespace MAP_CONFIG
 */
const MAP_CONFIG = {
    // Node sizing
    nodeRadius: 20,              // Default node circle radius in pixels
    clickRadius: 25,             // Click/touch detection radius (wider than node for easier mobile taps)
    innerIconRadius: 5,          // Offset from nodeRadius for inner icon circle
    selectionRingOffset: 3,      // Extra radius for selection highlight ring
    
    // Animation
    pulseSpeed: 0.05,            // Phase increment per animation frame
    pulseAmplitude: 5,           // Max pixels of pulse expansion
    glowPulseMultiplier: 2,      // Pulse speed multiplier for glow effects
    
    // Layout
    defaultCanvasHeight: 600,    // Fallback height if offsetHeight unavailable
    resizeDelay: 100,            // Ms delay before resize to ensure render
    
    // Tooltip positioning
    tooltipOffset: 10,           // Gap between node and tooltip
    labelOffset: 15,             // Gap below node for ID label
    
    // Connection lines
    connectionLineWidth: 2,      // Width of device connection lines
    connectionAlpha: 0.3,        // Opacity of connection lines
    
    // RSSI thresholds for distance calculation
    rssi: {
        strong: -70,             // dBm threshold for strong signal
        medium: -90,             // dBm threshold for medium signal
        weak: -110               // dBm threshold for weak signal (below = very weak)
    },
    
    // Distance visualization (RSSI to pixels mapping)
    distance: {
        minRadius: 80,           // Minimum distance from center (strong signal)
        maxRadius: 0.4,          // Max distance as fraction of canvas size
        maxRandomJitter: 30      // Random position jitter in pixels
    }
};

class NetworkMap {
    constructor(canvasId, detailsPanelId) {
        this.canvas = document.getElementById(canvasId);
        this.detailsPanel = document.getElementById(detailsPanelId);
        
        if (!this.canvas) {
            MAP_DEBUG.error(`Canvas element '${canvasId}' not found!`);
            throw new Error(`Canvas element '${canvasId}' not found`);
        }
        
        this.ctx = this.canvas.getContext('2d');
        if (!this.ctx) {
            MAP_DEBUG.error('Failed to get 2D context');
            throw new Error('Failed to get 2D context');
        }
        
        MAP_DEBUG.log('Canvas initialized:', this.canvas.width, 'x', this.canvas.height);
        
        // State
        this.devices = [];
        this.selectedNode = null;
        this.hoveredNode = null;
        
        // Layout - use config constants
        this.centerX = 0;
        this.centerY = 0;
        this.nodeRadius = MAP_CONFIG.nodeRadius;
        this.clickRadius = MAP_CONFIG.clickRadius;
        
        // Animation
        this.animationFrame = null;
        this.pulsePhase = 0;

        // View controls
        this.zoom = 1;
        this.showLabels = true;
        
        // Colors
        this.colors = {
            meshtastic: '#00d4aa',
            lorawan: '#4a90e2',
            helium: '#9b59b6',
            unknown: '#95a5a6',
            background: '#1a1a2e',
            grid: '#2a2a3e',
            text: '#ffffff',
            weakSignal: '#e74c3c',
            mediumSignal: '#f39c12',
            strongSignal: '#27ae60',
            threatHigh: '#e74c3c',      // Red - vulnerable
            threatMedium: '#f39c12',    // Orange - moderate risk
            threatLow: '#27ae60',       // Green - secure
            heatmapHigh: 'rgba(231, 76, 60, 0.3)',   // Red overlay
            heatmapMedium: 'rgba(243, 156, 18, 0.2)', // Orange overlay
            heatmapLow: 'rgba(39, 174, 96, 0.1)'      // Green overlay
        };
        
        this.showThreatColors = true;  // Toggle for threat vs protocol colors
        this.showHeatmap = true;        // Toggle for signal heatmap
        
        this.setupCanvas();
        this.setupEventListeners();
        this.startAnimation();
    }
    
    setupCanvas() {
        // Make canvas responsive
        const resizeCanvas = () => {
            const container = this.canvas.parentElement;
            if (!container) {
                MAP_DEBUG.error('Canvas has no parent element');
                return;
            }
            
            const oldWidth = this.canvas.width;
            const oldHeight = this.canvas.height;
            
            // Get actual container dimensions
            const rect = container.getBoundingClientRect();
            this.canvas.width = rect.width;
            this.canvas.height = this.canvas.offsetHeight || MAP_CONFIG.defaultCanvasHeight;
            
            this.centerX = this.canvas.width / 2;
            this.centerY = this.canvas.height / 2;
            
            MAP_DEBUG.log(`Canvas resized from ${oldWidth}x${oldHeight} to ${this.canvas.width}x${this.canvas.height}`);
            MAP_DEBUG.log(`Canvas offset dimensions: ${this.canvas.offsetWidth}x${this.canvas.offsetHeight}`);
            MAP_DEBUG.log(`New center point: (${this.centerX}, ${this.centerY})`);
            
            this.redraw();
        };
        
        // Store bound reference for cleanup in destroy()
        this.boundResizeHandler = resizeCanvas;
        window.addEventListener('resize', resizeCanvas);
        // Small delay to ensure canvas has rendered
        setTimeout(resizeCanvas, MAP_CONFIG.resizeDelay);
        resizeCanvas();
        
        MAP_DEBUG.log('Canvas setup complete:', this.canvas.width, 'x', this.canvas.height);
        MAP_DEBUG.log('Center point:', this.centerX, ',', this.centerY);
    }
    
    setupEventListeners() {
        MAP_DEBUG.log('Setting up event listeners on canvas:', this.canvas);
        MAP_DEBUG.log('Canvas element:', this.canvas.tagName, this.canvas.id);
        MAP_DEBUG.log('Canvas dimensions:', this.canvas.width, 'x', this.canvas.height);
        MAP_DEBUG.log('Canvas style.pointerEvents:', window.getComputedStyle(this.canvas).pointerEvents);
        MAP_DEBUG.log('Canvas style.cursor:', window.getComputedStyle(this.canvas).cursor);
        
        // Mouse events for desktop
        this.canvas.addEventListener('mousemove', (e) => {
            this.handleMouseMove(e);
        }, false);
        
        this.canvas.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            MAP_DEBUG.log('CLICK EVENT RECEIVED at client:', e.clientX, e.clientY);
            MAP_DEBUG.log('Canvas bounding rect:', this.canvas.getBoundingClientRect());
            this.handleClick(e);
        }, false);
        
        this.canvas.addEventListener('mouseleave', () => {
            this.hoveredNode = null;
            this.canvas.classList.remove('pointer-cursor');
            this.canvas.style.cursor = 'default';
        });
        
        // Touch events for mobile/iPhone
        this.canvas.addEventListener('touchstart', (e) => this.handleTouch(e), { passive: false });
        this.canvas.addEventListener('touchend', (e) => {
            // Clear hover state on touch end
            this.hoveredNode = null;
        }, { passive: true });
        
        MAP_DEBUG.log('Event listeners installed. Click the canvas to test.');
    }
    
    handleTouch(e) {
        e.preventDefault(); // Prevent scroll/zoom
        const touch = e.touches[0];
        const rect = this.canvas.getBoundingClientRect();
        const x = touch.clientX - rect.left;
        const y = touch.clientY - rect.top;
        
        const node = this.findNodeAtPosition(x, y);
        if (node) {
            this.selectedNode = node;
            this.showNodeDetails(node);
            this.canvas.style.cursor = 'pointer';
        } else {
            this.selectedNode = null;
            this.hideNodeDetails();
            this.canvas.style.cursor = 'default';
        }
    }
    
    handleMouseMove(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        // Check if mouse is over any node
        const node = this.findNodeAtPosition(x, y);
        
        // Update cursor using both class and style for maximum compatibility
        if (node) {
            this.canvas.classList.add('pointer-cursor');
            this.canvas.style.cursor = 'pointer';
        } else {
            this.canvas.classList.remove('pointer-cursor');
            this.canvas.style.cursor = 'default';
        }
        
        if (node !== this.hoveredNode) {
            this.hoveredNode = node;
            MAP_DEBUG.log('Hover state changed:', node ? `Device ${node.nodeId || node.source}` : 'none');
            
            // Trigger redraw to show hover state
            requestAnimationFrame(() => this.redraw());
        }
    }
    
    handleClick(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        MAP_DEBUG.log('===== CLICK DEBUG =====');
        MAP_DEBUG.log('Client click:', e.clientX, e.clientY);
        MAP_DEBUG.log('Canvas rect:', rect);
        MAP_DEBUG.log('Canvas position - left:', rect.left, 'top:', rect.top);
        MAP_DEBUG.log('Canvas size:', this.canvas.width, 'x', this.canvas.height);
        MAP_DEBUG.log('Calculated canvas coords:', x.toFixed(0), y.toFixed(0));
        MAP_DEBUG.log('Canvas center:', this.centerX, this.centerY);
        
        const node = this.findNodeAtPosition(x, y);
        if (node) {
            MAP_DEBUG.log('Device selected:', node.nodeId || node.source);
            this.selectedNode = node;
            this.showNodeDetails(node);
        } else {
            MAP_DEBUG.log('Clicked on empty area');
            this.selectedNode = null;
            this.hideNodeDetails();
        }
        
        // Trigger redraw
        this.redraw();
    }
    
    findNodeAtPosition(x, y) {
        const clickRadius = this.clickRadius || MAP_CONFIG.clickRadius;

        // Inverse-transform screen coords to world coords to account for zoom
        const worldX = (x - this.centerX) / this.zoom + this.centerX;
        const worldY = (y - this.centerY) / this.zoom + this.centerY;

        MAP_DEBUG.log(`Finding node at screen (${x.toFixed(0)}, ${y.toFixed(0)}) → world (${worldX.toFixed(0)}, ${worldY.toFixed(0)})`);
        MAP_DEBUG.log(`Total devices in array: ${this.devices.length}`);
        MAP_DEBUG.log(`Click radius: ${clickRadius}px, zoom: ${this.zoom}`);
        MAP_DEBUG.log(`Canvas center: (${this.centerX}, ${this.centerY})`);
        
        if (!this.devices || this.devices.length === 0) {
            MAP_DEBUG.log('No devices to check');
            return null;
        }
        
        for (const device of this.devices) {
            if (!device.position) {
                MAP_DEBUG.log('Device has no position:', device.nodeId || device.source);
                continue;
            }

            const dx = worldX - device.position.x;
            const dy = worldY - device.position.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            MAP_DEBUG.log(`Device ${device.nodeId || device.source} at (${device.position.x.toFixed(0)}, ${device.position.y.toFixed(0)}), distance=${distance.toFixed(1)}px`);
            
            if (distance <= clickRadius) {
                MAP_DEBUG.log(`✓ DEVICE FOUND! ${device.nodeId || device.source}, distance=${distance.toFixed(1)}px (threshold: ${clickRadius}px)`);
                return device;
            }
        }
        
        MAP_DEBUG.log('No device found within click radius');
        return null;
    }
    
    updateDevices(devices) {
        MAP_DEBUG.log('Updating with', devices.length, 'devices');
        
        if (!devices || devices.length === 0) {
            this.devices = [];
            MAP_DEBUG.log('No devices to display');
            return;
        }
        
        // Sort by vulnerability score (highest first = most vulnerable)
        devices.sort((a, b) => {
            const scoreA = this.calculateVulnerabilityScore(a);
            const scoreB = this.calculateVulnerabilityScore(b);
            return scoreB - scoreA; // Descending order
        });
        
        // Calculate positions for all devices
        this.devices = devices.map((device, index) => {
            // Convert RSSI to distance (higher RSSI = closer = smaller radius)
            // RSSI ranges typically from -120 (far) to -30 (close)
            const rssi = device.rssi || device.avgRSSI || -100;
            const normalizedRSSI = Math.max(-120, Math.min(-30, rssi));
            const distance = this.rssiToDistance(normalizedRSSI);
            
            // Arrange nodes in a circle, with distance from center based on RSSI
            const angle = (index / devices.length) * 2 * Math.PI;
            const x = this.centerX + Math.cos(angle) * distance;
            const y = this.centerY + Math.sin(angle) * distance;
            
            MAP_DEBUG.log(`Device ${index}: nodeId=${device.nodeId}, rssi=${rssi}, pos=(${x.toFixed(0)},${y.toFixed(0)}), distance=${distance.toFixed(0)}, center=(${this.centerX},${this.centerY})`);
            MAP_DEBUG.log('Canvas dimensions at positioning:', this.canvas.width, 'x', this.canvas.height);
            
            return {
                ...device,
                position: { x, y },
                angle: angle,
                vulnerabilityScore: this.calculateVulnerabilityScore(device)
            };
        });
        
        MAP_DEBUG.log('Positioned', this.devices.length, 'devices');
    }
    
    calculateVulnerabilityScore(device) {
        let score = 0;
        
        // High RSSI = device is close = more vulnerable to attack (0-3 points)
        const rssi = device.rssi || device.avgRSSI || -100;
        if (rssi > -50) score += 3;
        else if (rssi > -70) score += 2;
        else if (rssi > -90) score += 1;
        
        // Unencrypted or default PSK = highly vulnerable (0-4 points)
        if (device.hasDefaultPSK) score += 4;
        if (device.encrypted === false) score += 3;
        
        // Router devices are high-value targets (0-2 points)
        if (device.isRouter) score += 2;
        
        // High packet count = active device = valuable target (0-1 point)
        if (device.packetCount > 100) score += 1;
        
        return score; // Range: 0-10
    }
    
    getNodeColor(device) {
        if (this.showThreatColors) {
            // Use riskLevel from security API if available (from enriched data)
            if (device.riskLevel) {
                if (device.riskLevel === 'vulnerable') return this.colors.threatHigh;
                if (device.riskLevel === 'moderate') return this.colors.threatMedium;
                if (device.riskLevel === 'secure') return this.colors.threatLow;
            }
            // Fallback to calculated score
            const score = device.vulnerabilityScore || this.calculateVulnerabilityScore(device);
            if (score >= 7) return this.colors.threatHigh;      // 7-10: High threat
            if (score >= 4) return this.colors.threatMedium;    // 4-6: Medium threat
            return this.colors.threatLow;                        // 0-3: Low threat
        } else {
            // Use protocol-based colors
            const protocol = (device.protocol || 'unknown').toLowerCase();
            if (protocol.includes('meshtastic')) return this.colors.meshtastic;
            if (protocol.includes('lorawan')) return this.colors.lorawan;
            if (protocol.includes('helium')) return this.colors.helium;
            return this.colors.unknown;
        }
    }
    
    rssiToDistance(rssi) {
        // Map RSSI to canvas distance
        // -30 dBm (strong) = 50px from center
        // -120 dBm (weak) = 300px from center
        const minRadius = 50;
        const maxRadius = Math.min(this.canvas.width, this.canvas.height) * 0.4;
        const normalized = (rssi + 120) / 90; // Normalize to 0-1
        return minRadius + (1 - normalized) * (maxRadius - minRadius);
    }
    
    getNodeType(device) {
        // Determine if node is transmitter, relay-only, or mixed
        const originated = device.originatedPackets || 0;
        const relayed = device.relayedPackets || 0;
        
        if (originated > 0 && relayed > 0) return 'mixed';
        if (relayed > 0) return 'relay';
        return 'transmitter';  // Default for devices with no relay info
    }
    
    startAnimation() {
        const animate = () => {
            this.pulsePhase += MAP_CONFIG.pulseSpeed;
            this.redraw();
            this.animationFrame = requestAnimationFrame(animate);
        };
        animate();
    }
    
    stopAnimation() {
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame);
            this.animationFrame = null;
        }
    }
    
    redraw() {
        // Clear canvas
        this.ctx.fillStyle = this.colors.background;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Empty state: show message + pulsing center dot, skip all node drawing
        if (!this.devices || this.devices.length === 0) {
            this.drawCenter();
            this.drawEmptyState();
            this.drawLegend();
            return;
        }

        // Apply zoom transform centered on canvas midpoint
        this.ctx.save();
        this.ctx.translate(this.centerX, this.centerY);
        this.ctx.scale(this.zoom, this.zoom);
        this.ctx.translate(-this.centerX, -this.centerY);

        this.drawGrid();
        this.drawCenter();
        this.drawRangeCircles();
        if (this.showHeatmap) this.drawHeatmap();
        this.drawConnections();
        this.drawNodes();
        if (this.hoveredNode) this.drawTooltip(this.hoveredNode);

        this.ctx.restore();

        // Legend is fixed position — drawn outside zoom transform
        this.drawLegend();
    }
    
    drawGrid() {
        this.ctx.strokeStyle = this.colors.grid;
        this.ctx.lineWidth = 1;
        this.ctx.setLineDash([5, 5]);
        
        // Draw crosshair at center
        this.ctx.beginPath();
        this.ctx.moveTo(this.centerX, 0);
        this.ctx.lineTo(this.centerX, this.canvas.height);
        this.ctx.moveTo(0, this.centerY);
        this.ctx.lineTo(this.canvas.width, this.centerY);
        this.ctx.stroke();
        
        this.ctx.setLineDash([]);
    }
    
    drawCenter() {
        // Draw sniffer device at center
        const pulse = Math.sin(this.pulsePhase) * MAP_CONFIG.pulseAmplitude;
        
        this.ctx.fillStyle = '#ff6b6b';
        this.ctx.beginPath();
        this.ctx.arc(this.centerX, this.centerY, 15 + pulse, 0, 2 * Math.PI);
        this.ctx.fill();
        
        // Label
        this.ctx.fillStyle = this.colors.text;
        this.ctx.font = 'bold 12px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText('SNIFFER', this.centerX, this.centerY + 35);
    }
    
    drawHeatmap() {
        // Draw signal strength heatmap for each device
        this.devices.forEach(device => {
            if (!device.position) return;
            
            const rssi = device.rssi || device.avgRSSI || -100;
            const score = device.vulnerabilityScore || this.calculateVulnerabilityScore(device);
            
            // Determine heatmap radius based on RSSI (stronger signal = larger radius)
            let heatmapRadius = 80;
            if (rssi > -50) heatmapRadius = 120;
            else if (rssi > -70) heatmapRadius = 100;
            else if (rssi > -90) heatmapRadius = 80;
            else heatmapRadius = 60;
            
            // Create radial gradient based on threat level
            const gradient = this.ctx.createRadialGradient(
                device.position.x, device.position.y, 0,
                device.position.x, device.position.y, heatmapRadius
            );
            
            // Color based on threat level
            let centerColor, edgeColor;
            if (score >= 7) {
                centerColor = 'rgba(231, 76, 60, 0.4)';  // Red
                edgeColor = 'rgba(231, 76, 60, 0)';
            } else if (score >= 4) {
                centerColor = 'rgba(243, 156, 18, 0.3)'; // Orange
                edgeColor = 'rgba(243, 156, 18, 0)';
            } else {
                centerColor = 'rgba(39, 174, 96, 0.2)';  // Green
                edgeColor = 'rgba(39, 174, 96, 0)';
            }
            
            gradient.addColorStop(0, centerColor);
            gradient.addColorStop(1, edgeColor);
            
            this.ctx.fillStyle = gradient;
            this.ctx.beginPath();
            this.ctx.arc(device.position.x, device.position.y, heatmapRadius, 0, 2 * Math.PI);
            this.ctx.fill();
        });
    }
    
    drawRangeCircles() {
        const ranges = [50, 150, 250];
        this.ctx.strokeStyle = this.colors.grid;
        this.ctx.lineWidth = 1;
        this.ctx.setLineDash([2, 4]);
        
        for (const radius of ranges) {
            this.ctx.beginPath();
            this.ctx.arc(this.centerX, this.centerY, radius, 0, 2 * Math.PI);
            this.ctx.stroke();
        }
        
        this.ctx.setLineDash([]);
    }
    
    drawConnections() {
        // Draw lines from center to each node
        this.ctx.strokeStyle = 'rgba(74, 144, 226, 0.2)';
        this.ctx.lineWidth = 1;
        
        for (const device of this.devices) {
            if (!device.position) continue;
            
            this.ctx.beginPath();
            this.ctx.moveTo(this.centerX, this.centerY);
            this.ctx.lineTo(device.position.x, device.position.y);
            this.ctx.stroke();
        }
    }
    
    drawNodes() {
        for (const device of this.devices) {
            if (!device.position) continue;
            
            const isSelected = this.selectedNode && this.selectedNode.nodeIdDecimal === device.nodeIdDecimal;
            const isHovered = this.hoveredNode && this.hoveredNode.nodeIdDecimal === device.nodeIdDecimal;
            
            // Get color based on threat level or protocol
            const nodeColor = this.getNodeColor(device);
            
            // Draw outer glow if selected
            if (isSelected) {
                const glowPulse = Math.sin(this.pulsePhase * MAP_CONFIG.glowPulseMultiplier) * MAP_CONFIG.pulseAmplitude + MAP_CONFIG.pulseAmplitude;
                this.ctx.fillStyle = nodeColor + '40';
                this.ctx.beginPath();
                this.ctx.arc(device.position.x, device.position.y, this.nodeRadius + glowPulse, 0, 2 * Math.PI);
                this.ctx.fill();
            }
            
            // Determine node type (transmitter, relay, mixed)
            const nodeType = this.getNodeType(device);
            
            // Draw main node circle (solid for transmitters, hollow for relay-only)
            if (nodeType === 'relay') {
                // Hollow circle for relay-only nodes
                this.ctx.strokeStyle = nodeColor;
                this.ctx.lineWidth = 3;
                this.ctx.beginPath();
                this.ctx.arc(device.position.x, device.position.y, this.nodeRadius, 0, 2 * Math.PI);
                this.ctx.stroke();
            } else {
                // Solid circle for transmitters and mixed
                this.ctx.fillStyle = nodeColor;
                this.ctx.beginPath();
                this.ctx.arc(device.position.x, device.position.y, this.nodeRadius, 0, 2 * Math.PI);
                this.ctx.fill();
                
                // Add double circle for mixed nodes
                if (nodeType === 'mixed') {
                    this.ctx.strokeStyle = nodeColor;
                    this.ctx.lineWidth = 2;
                    this.ctx.beginPath();
                    this.ctx.arc(device.position.x, device.position.y, this.nodeRadius - MAP_CONFIG.innerIconRadius, 0, 2 * Math.PI);
                    this.ctx.stroke();
                }
            }
            
            // Draw border if hovered
            if (isHovered || isSelected) {
                this.ctx.strokeStyle = '#ffffff';
                this.ctx.lineWidth = 3;
                this.ctx.beginPath();
                this.ctx.arc(device.position.x, device.position.y, this.nodeRadius + MAP_CONFIG.selectionRingOffset, 0, 2 * Math.PI);
                this.ctx.stroke();
            }
            
            // Draw signal strength indicator
            this.drawSignalBars(device);
            
            // Draw node ID label (can be toggled off)
            if (this.showLabels) {
                this.ctx.fillStyle = this.colors.text;
                this.ctx.font = 'bold 10px Arial';
                this.ctx.textAlign = 'center';
                const nodeIdStr = device.nodeId || '';
                const shortId = nodeIdStr.length > 4 ? nodeIdStr.slice(-4) : nodeIdStr || '????';
                this.ctx.fillText(`0x..${shortId}`, device.position.x, device.position.y + this.nodeRadius + MAP_CONFIG.labelOffset);
            }
        }
    }
    
    drawSignalBars(device) {
        const rssi = device.rssi || device.avgRSSI || -100;
        let bars = 0;
        if (rssi > -70) bars = 3;
        else if (rssi > -85) bars = 2;
        else if (rssi > -100) bars = 1;
        
        const barWidth = 3;
        const barGap = 2;
        const startX = device.position.x - 7;
        const startY = device.position.y - 10;
        
        for (let i = 0; i < 3; i++) {
            this.ctx.fillStyle = i < bars ? this.colors.strongSignal : 'rgba(255, 255, 255, 0.2)';
            const barHeight = 4 + (i * 3);
            this.ctx.fillRect(startX + i * (barWidth + barGap), startY - barHeight, barWidth, barHeight);
        }
    }
    
    drawTooltip(device) {
        const padding = 10;
        const lineHeight = 18;
        const lines = [
            `ID: 0x${device.nodeId || 'Unknown'}`,
            `Protocol: ${device.protocol || 'Unknown'}`,
            `RSSI: ${(device.rssi || device.avgRSSI || 0).toFixed(1)} dBm`,
            `Packets: ${device.packetCount || 0}`
        ];
        
        // Calculate tooltip dimensions
        this.ctx.font = '12px Arial';
        const maxWidth = Math.max(...lines.map(line => this.ctx.measureText(line).width));
        const tooltipWidth = maxWidth + padding * 2;
        const tooltipHeight = lines.length * lineHeight + padding * 2;
        
        // Position tooltip near mouse
        let x = device.position.x + this.nodeRadius + MAP_CONFIG.tooltipOffset;
        let y = device.position.y - tooltipHeight / 2;
        
        // Keep tooltip on screen
        if (x + tooltipWidth > this.canvas.width) x = device.position.x - this.nodeRadius - tooltipWidth - MAP_CONFIG.tooltipOffset;
        if (y < 0) y = 0;
        if (y + tooltipHeight > this.canvas.height) y = this.canvas.height - tooltipHeight;
        
        // Draw tooltip background
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
        this.ctx.fillRect(x, y, tooltipWidth, tooltipHeight);
        
        // Draw tooltip border
        this.ctx.strokeStyle = '#4a90e2';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(x, y, tooltipWidth, tooltipHeight);
        
        // Draw text
        this.ctx.fillStyle = this.colors.text;
        this.ctx.textAlign = 'left';
        lines.forEach((line, index) => {
            this.ctx.fillText(line, x + padding, y + padding + (index + 1) * lineHeight);
        });
    }
    
    showNodeDetails(device) {
        if (!this.detailsPanel) {
            MAP_DEBUG.error('Details panel element not found - ID:', this.detailsPanelId || 'unknown');
            MAP_DEBUG.error('Available elements:', document.querySelectorAll('[id*="network"]'));
            return;
        }
        
        MAP_DEBUG.log('===== SHOWING DEVICE DETAILS =====');
        MAP_DEBUG.log('Device:', device);
        MAP_DEBUG.log('Panel element:', this.detailsPanel);
        MAP_DEBUG.log('Panel display before:', this.detailsPanel.style.display);
        
        const rssi = device.rssi || device.avgRSSI || 0;
        const lastSeen = this.formatLastSeen(device.lastSeenSecondsAgo);
        const vulnScore = device.vulnerabilityScore || this.calculateVulnerabilityScore(device);
        
        // Determine vulnerability level and color - use riskLevel from security API if available
        let vulnLevel = 'Low';
        let vulnColor = '#50c878';
        if (device.riskLevel === 'vulnerable' || vulnScore >= 7) {
            vulnLevel = 'High';
            vulnColor = '#ff6b6b';
        } else if (device.riskLevel === 'moderate' || vulnScore >= 4) {
            vulnLevel = 'Medium';
            vulnColor = '#ffd93d';
        }
        
        let html = '<div class="node-details-card" style="padding: 1.5rem; background: rgba(26, 26, 46, 0.95); border-radius: 8px; border: 2px solid rgba(74, 144, 226, 0.5); margin: 0.5rem 0;">';
        html += `<h3 style="margin: 0 0 1rem 0; color: #4a90e2; font-size: 1.2rem; font-weight: 600;">📡 Device 0x${escapeHtml(device.nodeId || 'Unknown')}</h3>`;
        
        html += '<div style="display: grid; gap: 0.75rem; font-size: 1rem;">';
        html += `<div style="display: flex; justify-content: space-between; padding: 0.5rem; background: rgba(255,255,255,0.05); border-radius: 4px;"><span style="color: #a0a0a0;">Protocol:</span><strong style="color: #e0e0e0;">${escapeHtml(device.protocol || 'Unknown')}</strong></div>`;
        html += `<div style="display: flex; justify-content: space-between; padding: 0.5rem; background: rgba(255,255,255,0.05); border-radius: 4px;"><span style="color: #a0a0a0;">Device Type:</span><strong style="color: #e0e0e0;">${escapeHtml(device.deviceType || 'Unknown')}</strong></div>`;
        html += `<div style="display: flex; justify-content: space-between; padding: 0.5rem; background: rgba(255,255,255,0.05); border-radius: 4px;"><span style="color: #a0a0a0;">RSSI:</span><strong style="color: #e0e0e0;">${rssi.toFixed(1)} dBm</strong></div>`;
        html += `<div style="display: flex; justify-content: space-between; padding: 0.5rem; background: rgba(255,255,255,0.05); border-radius: 4px;"><span style="color: #a0a0a0;">Packets:</span><strong style="color: #e0e0e0;">${device.packetCount || 0}</strong></div>`;
        html += `<div style="display: flex; justify-content: space-between; padding: 0.5rem; background: rgba(255,255,255,0.05); border-radius: 4px;"><span style="color: #a0a0a0;">Last Seen:</span><strong style="color: #e0e0e0;">${lastSeen}</strong></div>`;
        
        // Vulnerability indicator
        html += `<div style="margin-top: 0.5rem; padding: 1rem; background: rgba(255,255,255,0.08); border-radius: 6px; border-left: 4px solid ${vulnColor};">`;
        html += `<div style="display: flex; justify-content: space-between; align-items: center;">`;
        html += `<span style="color: #a0a0a0; font-weight: 600;">Vulnerability:</span>`;
        html += `<strong style="color: ${vulnColor}; font-size: 1.1rem;">${vulnLevel} (${vulnScore}/10)</strong>`;
        html += '</div>';
        
        // Vulnerability details
        if (device.hasDefaultPSK) {
            html += '<div style="margin-top: 0.5rem; font-size: 0.9rem; color: #ff6b6b; font-weight: 500;">⚠️ Default PSK detected</div>';
        }
        if (device.encrypted === false) {
            html += '<div style="margin-top: 0.5rem; font-size: 0.9rem; color: #ffd93d; font-weight: 500;">⚠️ Unencrypted</div>';
        }
        
        // Node type indicator
        const nodeType = this.getNodeType(device);
        const nodeTypeLabel = nodeType === 'transmitter' ? '⚡ Active Transmitter' : 
                             nodeType === 'relay' ? '↻ Relay Node' : '⚡↻ Mixed (TX+Relay)';
        const nodeTypeColor = nodeType === 'transmitter' ? '#50c878' : 
                             nodeType === 'relay' ? '#4a90e2' : '#9b59b6';
        html += `<div style="margin-top: 0.5rem; font-size: 0.9rem; color: ${nodeTypeColor}; font-weight: 500;">${nodeTypeLabel}</div>`;
        if (device.originatedPackets > 0) {
            html += `<div style="margin-top: 0.25rem; font-size: 0.85rem; color: #a0a0a0;">Originated: ${device.originatedPackets} packets</div>`;
        }
        if (device.relayedPackets > 0) {
            html += `<div style="margin-top: 0.25rem; font-size: 0.85rem; color: #a0a0a0;">Relayed: ${device.relayedPackets} packets</div>`;
        }
        
        if (device.isRouter) {
            html += '<div style="margin-top: 0.5rem; font-size: 0.9rem; color: #4a90e2; font-weight: 500;">🔀 Router/Gateway</div>';
        }
        html += '</div>';
        
        html += '</div>';
        html += '</div>';
        
        this.detailsPanel.innerHTML = html;
        this.detailsPanel.style.display = 'block';
        this.detailsPanel.style.visibility = 'visible';
        this.detailsPanel.style.opacity = '1';
        
        MAP_DEBUG.log('Panel innerHTML set, length:', html.length);
        MAP_DEBUG.log('Panel display after:', this.detailsPanel.style.display);
        MAP_DEBUG.log('Panel visibility:', this.detailsPanel.style.visibility);
        
        // Scroll the details panel into view
        setTimeout(() => {
            this.detailsPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            MAP_DEBUG.log('Scrolled panel into view');
        }, 100);
    }
    
    hideNodeDetails() {
        if (!this.detailsPanel) return;
        this.detailsPanel.style.display = 'none';
    }
    
    drawLegend() {
        const padding = 15;
        const startX = this.canvas.width - 180;
        const startY = 20;
        const lineHeight = 30;
        
        // Background
        this.ctx.fillStyle = 'rgba(26, 26, 46, 0.9)';
        this.ctx.fillRect(startX - padding, startY - padding, 160, 130);
        
        // Border
        this.ctx.strokeStyle = 'rgba(74, 144, 226, 0.5)';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(startX - padding, startY - padding, 160, 130);
        
        // Title
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = 'bold 12px Arial';
        this.ctx.fillText('Node Types', startX, startY);
        
        // Legend items
        this.ctx.font = '11px Arial';
        
        // Active Transmitter (solid circle)
        this.ctx.fillStyle = this.colors.meshtastic;
        this.ctx.beginPath();
        this.ctx.arc(startX, startY + lineHeight, 8, 0, 2 * Math.PI);
        this.ctx.fill();
        this.ctx.fillStyle = '#e0e0e0';
        this.ctx.fillText('Active Transmitter', startX + 15, startY + lineHeight + 4);
        
        // Relay-Only (hollow circle)
        this.ctx.strokeStyle = this.colors.lorawan;
        this.ctx.lineWidth = 3;
        this.ctx.beginPath();
        this.ctx.arc(startX, startY + lineHeight * 2, 8, 0, 2 * Math.PI);
        this.ctx.stroke();
        this.ctx.fillStyle = '#e0e0e0';
        this.ctx.fillText('Relay Only', startX + 15, startY + lineHeight * 2 + 4);
        
        // Mixed (double circle)
        this.ctx.fillStyle = this.colors.helium;
        this.ctx.beginPath();
        this.ctx.arc(startX, startY + lineHeight * 3, 8, 0, 2 * Math.PI);
        this.ctx.fill();
        this.ctx.strokeStyle = this.colors.helium;
        this.ctx.lineWidth = 2;
        this.ctx.beginPath();
        this.ctx.arc(startX, startY + lineHeight * 3, 5, 0, 2 * Math.PI);
        this.ctx.stroke();
        this.ctx.fillStyle = '#e0e0e0';
        this.ctx.fillText('Mixed (TX+Relay)', startX + 15, startY + lineHeight * 3 + 4);
    }
    
    formatLastSeen(secondsAgo) {
        if (secondsAgo === undefined || secondsAgo === null) return 'Unknown';
        if (secondsAgo === 0) return 'Just now';
        if (secondsAgo < 60) return `${Math.floor(secondsAgo)}s ago`;
        if (secondsAgo < 3600) return `${Math.floor(secondsAgo / 60)}m ago`;
        if (secondsAgo < 86400) return `${Math.floor(secondsAgo / 3600)}h ago`;
        return `${Math.floor(secondsAgo / 86400)}d ago`;
    }
    
    // ---- View controls (wired to map control buttons) ----

    centerMap() {
        this.zoom = 1;
        this.redraw();
    }

    toggleLabels() {
        this.showLabels = !this.showLabels;
        this.redraw();
        return this.showLabels;
    }

    zoomIn() {
        this.zoom = Math.min(3, this.zoom * 1.3);
        this.redraw();
    }

    zoomOut() {
        this.zoom = Math.max(0.3, this.zoom / 1.3);
        this.redraw();
    }

    drawEmptyState() {
        this.ctx.textAlign = 'center';
        this.ctx.font = '15px Arial';
        this.ctx.fillStyle = 'rgba(160, 160, 160, 0.6)';
        this.ctx.fillText('No devices detected yet', this.centerX, this.centerY - 30);
        this.ctx.font = '12px Arial';
        this.ctx.fillStyle = 'rgba(120, 120, 140, 0.6)';
        this.ctx.fillText('Nodes appear as packets are received', this.centerX, this.centerY - 10);
    }

    destroy() {
        this.stopAnimation();
        // Clean up resize listener to prevent memory leak
        if (this.boundResizeHandler) {
            window.removeEventListener('resize', this.boundResizeHandler);
            this.boundResizeHandler = null;
        }
    }
}

// Export for use in main app
window.NetworkMap = NetworkMap;
